import React, { useState, useEffect } from 'react';
import { ChevronDown, Clock, Shield, Target, Brain, Zap, Star, CheckCircle, X, Flame, Skull, Sword } from 'lucide-react';

function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState('');
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 59,
    seconds: 59
  });

  // Countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleChoice = (choice: 'yes' | 'no') => {
    if (choice === 'no') {
      setModalContent(`
        <div class="text-center">
          <h3 class="text-3xl font-bold text-red-500 mb-6">💀 EU JÁ SABIA 💀</h3>
          <p class="text-xl mb-6 text-gray-300">Você escolheu continuar sendo irrelevante. Parabéns, você acabou de confirmar que é exatamente o tipo de cara que eu pensei que fosse.</p>
          <p class="text-2xl font-bold text-white mb-6">"Quantos anos mais você vai desperdiçar sendo invisível?"</p>
          <p class="text-lg text-gray-300 mb-6">Enquanto você fica aí se escondendo, outros estão lá fora CONQUISTANDO tudo que você só sonha em ter. Você é só mais um na multidão.</p>
          <p class="text-xl text-red-500 font-bold">Mas ainda dá tempo de parar de ser um COVARDE. A escolha é sua, guerreiro.</p>
        </div>
      `);
    } else {
      setModalContent(`
        <div class="text-center">
          <h3 class="text-3xl font-bold text-green-500 mb-6">🔥 FINALMENTE, CARALHO! 🔥</h3>
          <p class="text-xl mb-6 text-gray-300">Você finalmente decidiu parar de se esconder e tomar uma atitude. Essa é a primeira decisão inteligente que você toma em anos!</p>
          <p class="text-2xl font-bold text-white mb-6">"Agora você vai descobrir o que é ser um VERDADEIRO GUERREIRO!"</p>
          <p class="text-lg text-gray-300 mb-6">Chega de desculpas esfarrapadas! Chega de choradeira! É hora de SANGRAR, SUAR e se tornar a MÁQUINA DE GUERRA que você nasceu para ser!</p>
          <p class="text-xl text-green-500 font-bold">CLIQUE NO BOTÃO ABAIXO E COMECE SUA TRANSFORMAÇÃO AGORA, GUERREIRO!</p>
        </div>
      `);
    }
    setIsModalOpen(true);
  };

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden relative">
      {/* Animated Fire Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-red-900/20 via-black to-red-950/30"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_80%,rgba(220,20,60,0.3)_0%,transparent_50%)] animate-pulse"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(139,0,0,0.4)_0%,transparent_50%)] animate-pulse"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_40%_40%,rgba(220,20,60,0.2)_0%,transparent_70%)] animate-ping"></div>
      </div>

      {/* Floating Particles */}
      <div className="fixed inset-0 z-1 pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-red-500 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${3 + Math.random() * 2}s`
            }}
          ></div>
        ))}
      </div>

      {/* Fixed Header with Warrior Logo */}
      <header className="fixed top-0 w-full bg-black/95 backdrop-blur-xl border-b-2 border-red-600 z-50 shadow-lg shadow-red-600/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center shadow-lg shadow-red-600/50">
              <Sword className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl md:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-red-600 to-red-700 tracking-wider animate-pulse">
              IRRECONHECÍVEL
            </h1>
            <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center shadow-lg shadow-red-600/50">
              <Flame className="w-6 h-6 text-white animate-bounce" />
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section with Background Image */}
      <section className="pt-24 pb-16 px-4 relative overflow-hidden min-h-screen flex items-center">
        {/* Background Image */}
        <div 
          className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat opacity-30"
          style={{ backgroundImage: 'url(/rain_warrior.jpg)' }}
        ></div>
        <div className="absolute inset-0 z-1 bg-gradient-to-b from-black/70 via-transparent to-black/90"></div>
        
        <div className="container mx-auto max-w-6xl relative z-10">
          <div className="text-center">
            {/* Ebook Cover with Glow Effect */}
            <div className="inline-block mb-8 relative">
              <div className="absolute inset-0 bg-red-600/30 blur-xl rounded-lg animate-pulse"></div>
              <img 
                src="/ebook_cover.png" 
                alt="Ebook Irreconhecível" 
                className="relative w-56 md:w-72 h-auto mx-auto rounded-lg shadow-2xl shadow-red-600/50 transform hover:scale-110 transition-all duration-500 animate-float border-2 border-red-600/50"
              />
              <div className="absolute -top-4 -right-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-bold animate-bounce">
                NOVO!
              </div>
            </div>
            
            {/* Brutal Headlines */}
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-black mb-8 leading-tight">
              <span className="block text-white drop-shadow-lg">VOCÊ NÃO É UM</span>
              <span className="block text-red-600 text-shadow-glow animate-pulse text-5xl md:text-7xl lg:text-8xl">DERROTADO</span>
              <span className="block text-white drop-shadow-lg">VOCÊ SÓ TÁ SE ESCONDENDO COMO UM</span>
            </h1>
            
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-8 text-gray-300 leading-relaxed max-w-4xl mx-auto">
              Eu sei quem você é. Você não precisa me contar. <span className="text-red-600 font-black">EU JÁ ESTIVE AÍ.</span>
              <br />Se olhando no espelho e sentindo <span className="text-red-600 font-black animate-pulse">NOJO</span>.
            </h2>
            
            <p className="text-xl md:text-2xl mb-10 text-gray-400 max-w-4xl mx-auto leading-relaxed font-semibold">
              Ignorado por mulher, por amigo, por parente. Tentando manter a pose... mas por dentro se sentindo um 
              <span className="text-red-600 font-bold"> MERDA</span>.
            </p>
            
            {/* CTA Button with Fire Effect */}
            <div className="relative inline-block mb-8">
              <div className="absolute inset-0 bg-gradient-to-r from-red-600 to-red-800 blur-lg animate-pulse"></div>
              <button 
                onClick={() => scrollToSection('cta')}
                className="relative bg-gradient-to-r from-red-600 via-red-700 to-red-800 hover:from-red-700 hover:via-red-800 hover:to-red-900 text-white font-black py-6 px-12 rounded-lg text-xl md:text-2xl transform hover:scale-110 transition-all duration-300 shadow-2xl shadow-red-600/50 border-2 border-red-500 animate-glow"
              >
                🔥 QUERO PARAR DE SER INVISÍVEL AGORA! 🔥
              </button>
            </div>
            
            {/* Brutal Countdown Timer */}
            <div className="bg-gradient-to-r from-red-900/80 via-black/80 to-red-900/80 backdrop-blur-lg rounded-xl p-6 border-2 border-red-600 max-w-lg mx-auto shadow-2xl shadow-red-600/30">
              <div className="flex items-center justify-center space-x-2 mb-3">
                <Skull className="w-6 h-6 text-red-500 animate-bounce" />
                <p className="text-lg font-bold text-red-400 tracking-wider">O RELÓGIO TÁ CORRENDO:</p>
                <Skull className="w-6 h-6 text-red-500 animate-bounce" />
              </div>
              <div className="flex justify-center space-x-6 text-3xl font-black">
                <div className="text-center">
                  <div className="text-red-500 bg-black/50 px-3 py-2 rounded-lg border border-red-600 animate-pulse">
                    {timeLeft.hours.toString().padStart(2, '0')}
                  </div>
                  <div className="text-xs text-gray-400 mt-1 font-bold">HORAS</div>
                </div>
                <div className="text-red-600 self-center animate-pulse">:</div>
                <div className="text-center">
                  <div className="text-red-500 bg-black/50 px-3 py-2 rounded-lg border border-red-600 animate-pulse">
                    {timeLeft.minutes.toString().padStart(2, '0')}
                  </div>
                  <div className="text-xs text-gray-400 mt-1 font-bold">MIN</div>
                </div>
                <div className="text-red-600 self-center animate-pulse">:</div>
                <div className="text-center">
                  <div className="text-red-500 bg-black/50 px-3 py-2 rounded-lg border border-red-600 animate-pulse">
                    {timeLeft.seconds.toString().padStart(2, '0')}
                  </div>
                  <div className="text-xs text-gray-400 mt-1 font-bold">SEG</div>
                </div>
              </div>
              <p className="text-center text-red-400 text-sm mt-3 font-bold">
                DEPOIS DISSO VOCÊ CONTINUA SENDO IRRELEVANTE!
              </p>
            </div>
          </div>
          
          {/* Scroll Indicator */}
          <div className="text-center mt-16">
            <ChevronDown className="w-10 h-10 text-red-600 mx-auto animate-bounce" />
            <p className="text-red-400 text-sm mt-2 font-bold">ROLE PARA BAIXO SE VOCÊ TEM CORAGEM</p>
          </div>
        </div>
      </section>

      {/* Problem Section - BRUTAL */}
      <section className="py-20 px-4 bg-gradient-to-b from-black via-red-950/20 to-black relative">
        <div className="container mx-auto max-w-6xl relative z-10">
          <h2 className="text-4xl md:text-6xl font-black text-center mb-16 text-red-600 animate-pulse">
            💀 A DOR REAL QUE VOCÊ VIVE (MAS NÃO ADMITE) 💀
          </h2>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <div className="absolute inset-0 bg-red-600/20 blur-xl rounded-lg"></div>
              <img 
                src="/discipline_aesthetic.jpg" 
                alt="Disciplina" 
                className="relative w-full rounded-lg shadow-2xl shadow-red-600/50 border-2 border-red-600/30 transform hover:scale-105 transition-all duration-500"
              />
            </div>
            
            <div className="space-y-8">
              <p className="text-2xl md:text-3xl text-gray-300 leading-relaxed font-bold">
                Seus amigos tão na balada, rindo, pegando geral. <span className="text-red-600 font-black">E VOCÊ?</span>
                <br />Preso em casa, fingindo que tá "focado", mas no fundo só queria ser <span className="text-red-600 font-black">NOTADO</span> por alguém.
              </p>
              
              <div className="bg-gradient-to-r from-red-950/50 to-black/50 p-6 rounded-lg border-l-4 border-red-600">
                <h3 className="text-2xl font-black text-red-600 mb-6 flex items-center">
                  <Skull className="w-8 h-8 mr-3 animate-bounce" />
                  ESSA É SUA VERDADE. CRUA. DURA. SEM FILTRO:
                </h3>
                {[
                  'Você finge que não liga pra mulher, mas MORRE por dentro toda vez que ela escolhe seu amigo',
                  'Você finge que tá focado em "dinheiro", mas não vende nada, não estuda nada, só MENTE pra si mesmo',
                  'Você finge que tem fé, mas não acredita nem em VOCÊ',
                  'Você diz que quer mudar... mas dorme até tarde, vive cansado e FOGE de qualquer desconforto',
                  'Você usa desculpas: "Ah, mas eles tiveram estrutura. Eu não."',
                  'E eu te digo: FODA-SE. Nada disso vai mudar o fato de que HOJE você ainda é IRRELEVANTE'
                ].map((item, index) => (
                  <div key={index} className="flex items-start space-x-4 mb-4">
                    <X className="w-6 h-6 text-red-500 flex-shrink-0 mt-1 animate-pulse" />
                    <span className="text-gray-300 text-lg font-semibold">{item}</span>
                  </div>
                ))}
              </div>
              
              <div className="bg-gradient-to-r from-red-600/20 to-red-800/20 p-6 rounded-lg border-2 border-red-600">
                <p className="text-2xl font-black text-white text-center">
                  E sabe o pior? <span className="text-red-600">NINGUÉM VAI VIR TE SALVAR.</span>
                  <br />Ou você muda, ou vai continuar sendo o cara que <span className="text-red-600">NINGUÉM ENXERGA</span>.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Story Section - David Goggins Style */}
      <section className="py-20 px-4 bg-gradient-to-b from-black via-red-950/10 to-black relative">
        <div className="container mx-auto max-w-4xl text-center relative z-10">
          <h2 className="text-4xl md:text-5xl font-black mb-12 text-red-600">
            🔥 AGORA VEM A PARTE BOA: VOCÊ AINDA PODE VIRAR ESSE JOGO 🔥
          </h2>
          
          <div className="bg-gradient-to-b from-red-950/30 to-black/50 p-8 rounded-xl border-2 border-red-600/50 shadow-2xl shadow-red-600/30">
            <p className="text-xl md:text-2xl text-gray-300 leading-relaxed mb-6">
              Você não precisa de outro cursinho de autoajuda com <span className="text-red-600 font-bold">FRASES BONITINHAS</span>.
              <br />Você precisa de um <span className="text-red-600 font-bold">CHAMADO PRA GUERRA</span>.
            </p>
            
            <p className="text-xl md:text-2xl text-gray-300 leading-relaxed mb-6">
              Esse ebook é um sistema de <span className="text-white font-black text-2xl">90 DIAS</span> pra destruir esse "você" invisível e reconstruir um <span className="text-red-600 font-bold">NOVO HOMEM</span>.
            </p>
            
            <p className="text-xl md:text-2xl text-gray-300 leading-relaxed mb-6">
              Mais forte. Mais frio. <span className="text-red-600 font-bold">MAIS FODA</span>.
            </p>
            
            <div className="bg-black/50 p-6 rounded-lg border border-red-600/30 mt-8">
              <p className="text-2xl font-black text-white">
                "Foda-se a infância, foda-se o privilégio, foda-se o que não deu certo.
                <br />É hora de <span className="text-red-600">FORJAR AÇO</span>!"
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-black via-red-950/20 to-black relative">
        <div className="container mx-auto max-w-6xl relative z-10">
          <h2 className="text-4xl md:text-6xl font-black text-center mb-16 text-red-600 animate-pulse">
            🔥 O MÉTODO "IRRECONHECÍVEL" 🔥
          </h2>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
            <div className="text-center lg:text-left">
              <div className="relative inline-block">
                <div className="absolute inset-0 bg-red-600/30 blur-2xl rounded-lg animate-pulse"></div>
                <img 
                  src="/ebook_cover.png" 
                  alt="Ebook Cover" 
                  className="relative w-80 h-auto mx-auto lg:mx-0 rounded-lg shadow-2xl shadow-red-600/50 transform hover:scale-110 transition-all duration-500 border-2 border-red-600/50 animate-float"
                />
              </div>
            </div>
            
            <div className="space-y-8">
              <p className="text-2xl md:text-3xl text-gray-300 leading-relaxed font-bold">
                Esse ebook é um sistema de <span className="text-red-600 font-black">90 DIAS</span> pra destruir esse "você" invisível e reconstruir um 
                <span className="text-red-600 font-black"> NOVO HOMEM</span>. Mais forte. Mais frio. 
                <span className="text-red-600 font-black"> MAIS FODA</span>.
              </p>
              
              <div className="bg-gradient-to-r from-red-950/50 to-black/50 p-6 rounded-lg border-2 border-red-600/50">
                <p className="text-xl font-black text-white text-center">
                  Não é mais um ebook de <span className="text-yellow-400">AUTOAJUDA</span>. 
                  É um <span className="text-red-600">CHAMADO PRA GUERRA</span> contra a mediocridade!
                </p>
              </div>
            </div>
          </div>
          
          {/* Benefits Grid - BRUTAL */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { 
                icon: Target, 
                title: '💪 FORJA DO CORPO', 
                desc: 'Físico imponente. Testosterona no talo. Treinos que vão te TRANSFORMAR numa máquina',
                color: 'from-red-600 to-red-800'
              },
              { 
                icon: Brain, 
                title: '🧠 BLINDAGEM MENTAL', 
                desc: 'Controle emocional. Constância. Foco. Disciplina que vai fazer você virar uma BESTA',
                color: 'from-orange-600 to-red-600'
              },
              { 
                icon: Zap, 
                title: '🎯 DESPERTAR BRUTAL', 
                desc: 'Descobrir quem CARALHOS você é. Encontre seu propósito e vire um GUERREIRO',
                color: 'from-yellow-600 to-orange-600'
              },
              { 
                icon: Star, 
                title: '⛪ FORÇA ESPIRITUAL', 
                desc: 'Fé inabalável, movida por DOR, não por "amor". Use sua fé como COMBUSTÍVEL',
                color: 'from-purple-600 to-red-600'
              }
            ].map((benefit, index) => (
              <div key={index} className={`bg-gradient-to-b ${benefit.color} p-6 rounded-xl border-2 border-white/20 hover:border-white/60 transition-all duration-300 hover:transform hover:scale-110 shadow-2xl hover:shadow-red-600/50 group`}>
                <benefit.icon className="w-16 h-16 text-white mb-4 mx-auto group-hover:animate-bounce" />
                <h4 className="text-lg font-black text-white mb-4 text-center">{benefit.title}</h4>
                <p className="text-white text-center text-sm font-bold leading-relaxed">{benefit.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Choice Section - BRUTAL */}
      <section className="py-20 px-4 bg-gradient-to-b from-black via-red-950/30 to-black relative">
        <div className="container mx-auto max-w-5xl text-center relative z-10">
          <h2 className="text-4xl md:text-6xl font-black mb-12 text-red-600 animate-pulse">
            ⏰ O RELÓGIO TÁ CORRENDO, SEU GUERREIRO! ⏰
          </h2>
          
          <p className="text-2xl md:text-3xl mb-8 text-gray-300 font-bold leading-relaxed">
            O mundo já tá lotado de <span className="text-yellow-400 font-black">HOMEM MOLE</span>. 
            Não seja mais um na <span className="text-red-600 font-black">MULTIDÃO</span>!
          </p>
          
          <div className="bg-gradient-to-r from-red-950/50 to-black/50 p-8 rounded-xl border-2 border-red-600 mb-12">
            <p className="text-3xl font-black text-white">
              Ninguém vai vir te salvar. Ou você muda, ou vai continuar sendo o cara que <span className="text-red-600">NINGUÉM ENXERGA</span>!
            </p>
          </div>
          
          <h3 className="text-2xl font-black mb-12 text-red-600">VOCÊ TEM DUAS OPÇÕES:</h3>
          
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <div 
              onClick={() => handleChoice('no')}
              className="bg-gradient-to-b from-red-900/50 to-red-950/70 p-8 rounded-xl border-2 border-red-800 cursor-pointer hover:border-red-600 transition-all duration-300 hover:transform hover:scale-105 shadow-2xl hover:shadow-red-600/50 group"
            >
              <div className="text-5xl font-black text-red-600 mb-6 group-hover:animate-bounce">1.</div>
              <p className="text-gray-300 mb-6 text-xl font-bold leading-relaxed">
                Fechar essa página, continuar <span className="text-red-600 font-black">RECLAMANDO</span>, 
                e ver seus amigos crescendo enquanto você <span className="text-yellow-400 font-black">SOME</span>
              </p>
              <button className="bg-transparent border-2 border-red-600 text-red-600 px-6 py-3 rounded-lg hover:bg-red-600 hover:text-white transition-all duration-300 font-black text-lg">
                SOU UM COVARDE
              </button>
            </div>
            
            <div 
              onClick={() => handleChoice('yes')}
              className="bg-gradient-to-b from-green-900/50 to-green-950/70 p-8 rounded-xl border-2 border-green-800 cursor-pointer hover:border-green-600 transition-all duration-300 hover:transform hover:scale-105 shadow-2xl hover:shadow-green-600/50 group"
            >
              <div className="text-5xl font-black text-green-600 mb-6 group-hover:animate-bounce">2.</div>
              <p className="text-gray-300 mb-6 text-xl font-bold leading-relaxed">
                Clicar aqui embaixo, comprar essa porra e começar sua <span className="text-green-600 font-black">TRANSFORMAÇÃO</span>
              </p>
              <button className="bg-transparent border-2 border-green-600 text-green-600 px-6 py-3 rounded-lg hover:bg-green-600 hover:text-white transition-all duration-300 font-black text-lg">
                SOU UM GUERREIRO
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section - FINAL BRUTAL */}
      <section id="cta" className="py-20 px-4 bg-gradient-to-b from-black via-red-950/40 to-black relative">
        <div className="container mx-auto max-w-5xl text-center relative z-10">
          <h2 className="text-4xl md:text-6xl font-black mb-8 text-white">
            ⚔️ CLIQUE E COMPRE AGORA ⚔️
          </h2>
          <p className="text-2xl md:text-3xl mb-12 text-gray-300 font-bold">
            Por apenas <span className="text-5xl font-black text-red-600 animate-pulse">R$ 47,00</span> 
            <br />você para de ser <span className="text-red-600 font-black">INVISÍVEL</span>!
          </p>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-12">
            <div className="relative">
              <div className="absolute inset-0 bg-red-600/40 blur-2xl rounded-lg animate-pulse"></div>
              <img 
                src="/ebook_cover.png" 
                alt="Ebook Final" 
                className="relative w-80 h-auto mx-auto rounded-lg shadow-2xl shadow-red-600/70 border-4 border-red-600/50 animate-float"
              />
            </div>
            
            <div className="space-y-8">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-red-600 to-red-800 blur-xl animate-pulse"></div>
                <button 
                  onClick={() => alert('🔥 FINALMENTE! Redirecionando para o checkout... Prepare-se para se tornar IRRECONHECÍVEL!')}
                  className="relative bg-gradient-to-r from-red-600 via-red-700 to-red-800 hover:from-red-700 hover:via-red-800 hover:to-red-900 text-white font-black py-8 px-12 rounded-xl text-2xl md:text-3xl transform hover:scale-110 transition-all duration-300 shadow-2xl shadow-red-600/70 w-full border-4 border-red-500 animate-glow"
                >
                  💀 QUERO PARAR DE SER INVISÍVEL! 💀
                </button>
              </div>
              
              <div className="bg-gradient-to-r from-green-950/50 to-black/50 p-6 rounded-xl border-2 border-green-600/50">
                <div className="flex items-center justify-center space-x-3 text-green-400 mb-3">
                  <Shield className="w-8 h-8" />
                  <span className="font-black text-xl">GARANTIA DE 7 DIAS</span>
                  <Shield className="w-8 h-8" />
                </div>
                <p className="text-gray-300 font-bold">
                  Mas se você pedir reembolso, já sei que não tem <span className="text-green-400">COLHÃO</span> mesmo.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final Section - EPIC */}
      <section className="py-20 px-4 bg-gradient-to-b from-black via-red-950/30 to-black relative">
        <div 
          className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{ backgroundImage: 'url(/crusader_christ.jpg)' }}
        ></div>
        <div className="absolute inset-0 z-1 bg-gradient-to-b from-black/80 via-transparent to-black/90"></div>
        
        <div className="container mx-auto max-w-4xl text-center relative z-10">
          <h2 className="text-4xl md:text-6xl font-black mb-12 text-red-600 leading-tight">
            ⚔️ STAY HARD, SEU GUERREIRO ⚔️
            <span className="block text-white mt-4">AQUI NÃO TEM ESPAÇO PRA VÍTIMA</span>
          </h2>
          
          <div className="bg-gradient-to-b from-red-950/50 to-black/70 p-8 rounded-xl border-2 border-red-600/50 shadow-2xl shadow-red-600/30">
            <p className="text-2xl md:text-3xl mb-8 text-gray-300 leading-relaxed font-bold">
              Aqui é onde <span className="text-red-600 font-black">INVISÍVEIS</span> viram 
              <span className="text-red-600 font-black"> MÁQUINA</span>. 
              Ou somem da porra do mapa.
            </p>
            
            <div className="bg-black/50 p-6 rounded-lg border border-red-600/30">
              <p className="text-3xl md:text-4xl font-black text-white tracking-wider animate-pulse">
                VAMOS DESTRUIR ESSA CASCA FRACA E <span className="text-red-600">FORJAR AÇO</span>!
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 bg-black border-t-2 border-red-600 relative z-10">
        <div className="container mx-auto text-center">
          <p className="text-gray-600 text-sm mb-2 font-bold">
            &copy; 2025 Irreconhecível. Todos os direitos reservados.
          </p>
          <p className="text-gray-600 text-xs">
            Este produto não substitui acompanhamento médico ou psicológico profissional.
          </p>
        </div>
      </footer>

      {/* Modal - BRUTAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-lg z-50 flex items-center justify-center p-4">
          <div className="bg-gradient-to-b from-red-950/90 to-black/90 p-8 rounded-xl border-4 border-red-600 max-w-2xl w-full relative shadow-2xl shadow-red-600/50">
            <button 
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 text-red-600 hover:text-red-400 transition-colors"
            >
              <X className="w-8 h-8" />
            </button>
            <div dangerouslySetInnerHTML={{ __html: modalContent }} />
            <button 
              onClick={() => setIsModalOpen(false)}
              className="bg-gradient-to-r from-red-600 to-red-800 text-white font-black py-4 px-8 rounded-lg mt-8 w-full hover:from-red-700 hover:to-red-900 transition-all duration-300 text-xl"
            >
              CONTINUAR A JORNADA
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;